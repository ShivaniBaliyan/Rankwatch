import { Component } from '@angular/core';


@Component({
  selector: 'navbar',
  templateUrl: './app.component.html',
  styleUrls: ['../../assets/css/style.css']
})
export class HeaderComponent {
  title = 'Rankwatch';
}
