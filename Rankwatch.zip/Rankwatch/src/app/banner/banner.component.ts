import { Component } from '@angular/core';

@Component({
  selector: 'banner',
  templateUrl: 'banner.component.html',
  styleUrls: ['../../assets/css/style.css']
})
export class BannerComponent {
}