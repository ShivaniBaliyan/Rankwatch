import { Component } from '@angular/core';


@Component({
  selector: 'footer',
  templateUrl: './footer.component.html',
  styleUrls: ['../../assets/css/style.css']
})
export class FooterComponent {
}
