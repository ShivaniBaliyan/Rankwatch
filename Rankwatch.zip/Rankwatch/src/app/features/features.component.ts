import { Component } from '@angular/core';

@Component({
  selector: 'features',
  templateUrl: 'features.component.html',
  styleUrls: ['../../assets/css/style.css']
})
export class FeaturesComponent {
}