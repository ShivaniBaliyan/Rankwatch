import { Component } from '@angular/core';

@Component({
  selector: 'gallery',
  templateUrl: 'gallery.component.html',
  styleUrls: ['../../assets/css/style.css']
})
export class GalleryComponent {
}